Progetto Sokoban del gruppo Dank Memes

Formato da 	177002, Lo Faro, Riccardo, riccardolofaro97@gmail.com, 3356256674
		176185, Donadio, Gaetano, donadio24@gmail.com, 3428418481
		176220, Laurito, Domenico, www.domenico.96@gmail.com, 3485853100



Per Compilare:
g++ *.cpp -lallegro -lallegro_image -lallegro_primitives -lallegro_dialog -lallegro_audio -lallegro_acodec -lallegro_font -lallegro_ttf
